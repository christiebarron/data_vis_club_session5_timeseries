## Intro
- this data is from a [2017 Kaggle competition](https://www.kaggle.com/code/muonneutrino/wikipedia-traffic-data-exploration/data?ref=hackernoon.com). See https://www.kaggle.com/code/muonneutrino/wikipedia-traffic-data-exploration/data?ref=hackernoon.com for more information.

- the `data_wrangle.ipynb` is the jupyter notebook I used to wrangle the data. Raw data are in the `raw_data` folder, cleaned data are in the `clean_data` folder. 

- the `clean_data` include all cleaned datafiles after processing. 

- the `raw_data` include the raw datafile from kaggle. 